﻿using System;

class Program
{
    public static void Main()
    {
        int n1 = 10;
        Console.WriteLine(n1);

        int n2 = 10;
        var n3 = n2; // 우변의 표현식을 보고 좌변의 타입을 결정하겠다. C++의 auto
    }
}