﻿using System;

class Program
{
    static void Main()
    {
        //string s = Console.ReadLine();
        //Console.WriteLine(s);

        string s = Console.ReadLine();
        int n = Convert.ToInt32(s);
        Console.WriteLine(n);

        int c1 = Console.Read();
        Console.WriteLine(c1);
    }
}

