﻿using System;

class Program
{
    static void Main()
    {
        int[] arr1 = { 1, 2, 3, 4, 5 };
        string[] arr2 = { "aa", "bb", "cc" };
    }
}