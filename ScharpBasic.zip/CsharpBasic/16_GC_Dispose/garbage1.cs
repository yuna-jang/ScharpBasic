﻿using System;

class Program
{
    public static void Foo()
    {
        int n2 = 0;
    }
    static void Main()
    {
        int n1 = 0;
        Foo();
    }
}